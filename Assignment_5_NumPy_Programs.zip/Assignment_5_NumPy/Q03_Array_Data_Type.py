import numpy as np

# Create integer and decimal arrays
int_arr = np.array([10, 20, 30])
decimal_arr = np.array([1.5, 2.5, 3.5])

# Display data types
print("Integer Array Type:", int_arr.dtype)
print("Decimal Array Type:", decimal_arr.dtype)
