import numpy as np

# Create numbers from 1 to 10
arr = np.arange(1, 11)

# Reverse the array using slicing
reversed_arr = arr[::-1]

# Display both arrays
print("Original:", arr)
print("Reversed:", reversed_arr)
