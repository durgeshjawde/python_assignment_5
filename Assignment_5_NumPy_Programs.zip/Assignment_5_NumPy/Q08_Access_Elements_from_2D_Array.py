import numpy as np

# Create a 2D array
arr = np.array([[10, 20, 30], [40, 50, 60], [70, 80, 90]])

# Display selected elements
print(arr[0, 1])
print(arr[1, 2])
print(arr[2, 0])
