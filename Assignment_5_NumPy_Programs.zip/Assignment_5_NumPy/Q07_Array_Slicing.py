import numpy as np

# Create numbers from 1 to 10
arr = np.arange(1, 11)

# Display slices of the array
print("First 5:", arr[:5])
print("Last 5:", arr[5:])
print("Index 2 to 6:", arr[2:7])
