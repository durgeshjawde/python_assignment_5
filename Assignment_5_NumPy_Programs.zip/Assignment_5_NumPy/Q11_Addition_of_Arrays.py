import numpy as np

# Create two arrays
arr1 = np.array([10, 20, 30])
arr2 = np.array([5, 10, 15])

# Add corresponding elements
print("Result:", arr1 + arr2)
