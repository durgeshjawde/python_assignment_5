import numpy as np

# Create an array
arr = np.array([10, 20, 30, 40, 50])
print("Original Array:", arr)

# Change the second and last elements
arr[1] = 25
arr[-1] = 55

# Display updated array
print("Updated Array:", arr)
