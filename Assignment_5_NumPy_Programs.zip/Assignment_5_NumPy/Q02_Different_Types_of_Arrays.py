import numpy as np

# Create arrays using NumPy functions
zeros = np.zeros(5)
ones = np.ones(5)
numbers = np.arange(1, 11)

# Display all arrays
print("Zeros:", zeros)
print("Ones:", ones)
print("Range:", numbers)
