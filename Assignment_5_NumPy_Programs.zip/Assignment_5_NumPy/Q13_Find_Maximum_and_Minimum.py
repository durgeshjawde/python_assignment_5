import numpy as np

# Create an array of 10 numbers
arr = np.array([12, 45, 23, 67, 10, 89, 34, 56, 78, 20])

# Find maximum and minimum values
print("Array:", arr)
print("Maximum:", np.max(arr))
print("Minimum:", np.min(arr))
