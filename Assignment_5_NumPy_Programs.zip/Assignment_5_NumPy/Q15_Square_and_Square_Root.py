import numpy as np

# Create the given array
arr = np.array([1, 4, 9, 16, 25])

# Calculate squares and square roots
print("Square:", np.square(arr))
print("Square Root:", np.sqrt(arr))
