import numpy as np

# Create a one-dimensional array
arr = np.array([10, 20, 30, 40, 50])

# Display array properties
print("Array:", arr)
print("Dimensions:", arr.ndim)
print("Shape:", arr.shape)
print("Size:", arr.size)
