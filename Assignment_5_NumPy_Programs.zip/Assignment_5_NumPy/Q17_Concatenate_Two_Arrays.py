import numpy as np

# Create two arrays
arr1 = np.array([10, 20, 30])
arr2 = np.array([40, 50, 60])

# Combine the arrays
combined = np.concatenate((arr1, arr2))

# Display arrays
print("Array 1:", arr1)
print("Array 2:", arr2)
print("Combined Array:", combined)
