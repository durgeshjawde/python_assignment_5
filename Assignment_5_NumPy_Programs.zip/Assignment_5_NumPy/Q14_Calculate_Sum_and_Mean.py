import numpy as np

# Create an array of numbers
arr = np.array([10, 20, 30, 40, 50])

# Calculate statistics
print("Array:", arr)
print("Sum:", np.sum(arr))
print("Mean:", np.mean(arr))
print("Standard Deviation:", round(np.std(arr), 2))
