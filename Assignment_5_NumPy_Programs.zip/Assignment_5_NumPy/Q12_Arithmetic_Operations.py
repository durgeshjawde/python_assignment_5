import numpy as np

# Create two arrays
arr1 = np.array([10, 20, 30])
arr2 = np.array([5, 10, 15])

# Perform arithmetic operations
print("Addition:", arr1 + arr2)
print("Subtraction:", arr1 - arr2)
print("Multiplication:", arr1 * arr2)
print("Division:", arr1 / arr2)
