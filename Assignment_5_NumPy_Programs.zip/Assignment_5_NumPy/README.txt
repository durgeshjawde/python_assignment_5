MindSpar - Ctronics InfoTech
Assignment 5: NumPy Programs

Contains 20 separate Python programs (Q01 to Q20), each with short comments.

To run: install NumPy using: pip install numpy
Then open a Qxx file in VS Code and run it.

Note: Integer dtype may display as int32 or int64 depending on your system.
