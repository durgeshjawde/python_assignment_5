import numpy as np

# Create numbers from 1 to 12
arr = np.arange(1, 13)

# Reshape into 3 rows and 4 columns
reshaped = arr.reshape(3, 4)

# Display original and reshaped arrays
print("Original:")
print(arr)
print("Reshaped:")
print(reshaped)
