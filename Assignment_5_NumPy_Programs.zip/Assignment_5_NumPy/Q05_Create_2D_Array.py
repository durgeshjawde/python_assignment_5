import numpy as np

# Create a 3 by 3 array
arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]])

# Display array and its shape
print("Array:")
print(arr)
print("Shape:", arr.shape)
