import numpy as np

# Create a list of numbers
numbers = [10, 20, 30, 40, 50]

# Convert list to NumPy array
arr = np.array(numbers)

# Display the array
print("Array:", arr)
