import numpy as np

# Create an unsorted array
arr = np.array([45, 12, 78, 23, 9, 56])

# Sort the array
sorted_arr = np.sort(arr)

# Display original and sorted arrays
print("Original:", arr)
print("Sorted:", sorted_arr)
