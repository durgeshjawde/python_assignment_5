import numpy as np

# Create numbers from 1 to 20
arr = np.arange(1, 21)

# Select numbers greater than 10
filtered = arr[arr > 10]

# Display selected values
print("Numbers greater than 10:", filtered)
