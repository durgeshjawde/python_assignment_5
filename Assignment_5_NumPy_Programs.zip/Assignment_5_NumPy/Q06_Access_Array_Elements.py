import numpy as np

# Create an array
arr = np.array([10, 20, 30, 40, 50])

# Display selected elements
print("First Element:", arr[0])
print("Third Element:", arr[2])
print("Last Element:", arr[-1])
